def calculate_rsi14(closePrice):
    closePrice.reverse()
    rsi14 = []
    change = calculate_change(closePrice)
    gain = calculate_gain(change)
    loss = calculate_loss(change)
    avg_gain = calculate_avg_gain(gain)
    avg_loss = calculate_avg_loss(loss)
    rs = calculate_rs(avg_gain, avg_loss)
    x = 0
    while x < len(rs):
        y = 100 - 100 / (1+rs[x])
        rsi14.append(y)
        x += 1
    rsi14.reverse()
    return rsi14


def calculate_change(close_price):
    change = []
    x = 0
    while x < len(close_price):
        if x == 0:
            change.append(0)
            x += 1
            continue
        else:
            c = close_price[x] - close_price[x-1]
            change.append(c)
            x += 1
    return change


def calculate_gain(change):
    gain = []
    x = 0
    while x < len(change):
        if change[x] > 0:
            gain.append(change[x])
            x += 1
            continue
        else:
            gain.append(0)
            x += 1
    return gain


def calculate_loss(change):
    loss = []
    x = 0
    while x < len(change):
        if change[x] < 0:
            loss.append(abs(change[x]))
            x += 1
            continue
        else:
            loss.append(0)
            x += 1
    return loss


def calculate_avg_gain(gain):
    avg_gain = []
    x = 0
    while x < len(gain):
        if x < 14:
            avg_gain.append(0)
            x += 1
            continue
        elif x == 14:
            y = sum(gain[:15]) / 14
            avg_gain.append(y)
            x += 1
        else:
            y = (avg_gain[x-1] * 13 + gain[x]) / 14
            avg_gain.append(y)
            x += 1
    return avg_gain


def calculate_avg_loss(loss):
    avg_loss = []
    x = 0
    while x < len(loss):
        if x < 14:
            avg_loss.append(0)
            x += 1
            continue
        elif x == 14:
            y = sum(loss[:15]) / 14
            avg_loss.append(y)
            x += 1
        else:
            y = (avg_loss[x-1] * 13 + loss[x]) / 14
            avg_loss.append(y)
            x += 1
    return avg_loss


def calculate_rs(avg_gain, avg_loss):
    rs = []
    x = 0
    while x < len(avg_gain):
        if x < 14:
            rs.append(0)
            x += 1
        else:
            y = avg_gain[x] / avg_loss[x]
            rs.append(y)
            x += 1
    return rs